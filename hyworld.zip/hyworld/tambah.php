<?php
session_start();
if(!isset($_SESSION['login'])){
    header("location:login.php?pesan=logindulu");
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="icon" type="image/x-icon" href="logo.png">
    <title>ₕy-ω๏гɭり</title>
</head>
<style>
    body{
        background: gray;
    }
</style>
<body><br><br><div class="container">
    <div class="card">
        <div class="card-body">
            <a href="index.php"><button class="btn btn-dark">Back</button></a>
            <center><h1>Tambah Postingan</h1></center><br><br>
    <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        <label for="">Gambar</label><br>
        <input type="file" name="gambar" id="" class="form-control" required><br><br>

        <label for="">Caption</label><br>
        <textarea name="caption" id="" cols="30" rows="10" class="form-control" autocomplete="off"></textarea><br><br>

        <label for="">Lokasi</label><br>
        <input type="text" name="lokasi" id="" class="form-control" autocomplete="off"><br><br>

        <input type="submit" value="SIMPAN" name="simpan" class="btn btn-success">
    </form>
    </div>
    </div>
</div><br><br>
</body>
</html>