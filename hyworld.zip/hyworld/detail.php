<?php
session_start();
if(!isset($_SESSION['login'])){
    header("location:login.php?pesan=logindulu");
}
include "koneksi.php";
$no = $_GET['no'];
$sql = "SELECT * FROM post WHERE no='$no'";
$query = mysqli_query($koneksi,$sql);
while($post = mysqli_fetch_assoc($query)){
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" type="image/x-icon" href="logo.png">
    <title>ₕy-ω๏гɭり</title>
</head>
<body><br><br>
<div class="container">
        <center>
	<div class="col-sm-6">
		<div class="card-deck">
		  <div class="card"><br>
      <div class="img-hover-zoom img-hover-zoom--colorize">
		    <img src="gambar/<?= $post['gambar'] ?>" class="card-img-top" alt="gambar" width="100">
    </div>
		    <div class="card-body">
		      <p class="card-text"><?= $post['lokasi'] ?></p>
		    </div>
		    <div class="card-footer">
		      <small class="text-muted"><?= $post['caption'] ?></small>
		    </div>
    </div>
		  </div><br><br></center>
</div>
</body>
</html>
<?php } ?>

