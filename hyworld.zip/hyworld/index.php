<?php
session_start();
if(!isset($_SESSION['login'])){
    header("location:login.php?pesan=logindulu");
}
include "koneksi.php";
$sql = "SELECT * FROM post order by no desc";
$query = mysqli_query($koneksi,$sql);
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.2/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-T3c6CoIi6uLrA9TneNEoa7RxnatzjcDSCmG1MXxSR1GAsXEV/Dwwykc2MPK8M2HN" crossorigin="anonymous">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="icon" type="image/x-icon" href="logo.png">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@10.15.7/dist/sweetalert2.all.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.2/dist/js/bootstrap.min.js" integrity="sha384-cVKIPhGWiC2Al4u+LWgxfKTRIcfu0JTxR+EQDz/bgldoEyl4H0zUF0QKbrJ0EcQF" crossorigin="anonymous"></script>
    <title>ₕy-ω๏гɭり</title>
</head>
<nav class="navbar navbar-expand-lg bg-dark sticky-top" data-bs-theme="dark" >
  <div class="container-fluid">
    <img src="logo.png" width="20px" alt=""> |
    <a class="navbar-brand" href="#"><h4>ₕy-ω๏гɭり</h4></a>
    <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
      <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarSupportedContent">
      <ul class="navbar-nav me-auto mb-2 mb-lg-0">
        <li class="nav-item">
          
        </li>
      </ul>
      <!-- Button trigger modal -->
<button type="button" class="btn btn-success" data-bs-toggle="modal" data-bs-target="#staticBackdrop">
<i class="fa fa-plus" style="font-size:15px;color:white"></i>
</button>|
        <a href="logout.php"><button class="btn btn-secondary"><i class="fa fa-sign-out" style="font-size:15px;color:white"></i></button></a>
    </div>
  </div>

  <style>
    body {
      width: 736px;
      margin: 10px auto;
      border: 2px solid black;
    }
    /* img {
      padding: 10px;
      width: 300px;
      height: 200px;
    } */
    .img-hover-zoom--colorize img {
  transition: transform .5s, filter 1.5s ease-in-out;
  filter: grayscale(50%);
}
.img-hover-zoom--colorize:hover img {
  filter: grayscale(0);
  transform: scale(1.1);
}
  </style>
</nav>
<body><br><br>
<div class="container">
    <?php while($post=mysqli_fetch_assoc($query)) { ?>
        <center>
	<div class="col-sm-6">
		<div class="card-deck">
		  <div class="card"><br>
      <div class="img-hover-zoom img-hover-zoom--colorize">
		    <img src="gambar/<?= $post['gambar'] ?>" class="card-img-top" alt="gambar" width="100">
    </div>
		    <div class="card-body">
		      <p class="card-text"><?= $post['lokasi'] ?></p>
		    </div>
		    <div class="card-footer">
		      <small class="text-muted"><?= $post['caption'] ?></small>
		    </div>
        <div class="card-footer">
          <button class="btn btn-danger btn-x5" onclick="confirmDelete(<?php echo $post['no']; ?>)"><i class="fa fa-trash" style="font-size:20px;color:black"></i></button>
                 <button type="button" class="btn btn-warning" data-bs-toggle="modal" data-bs-target="#exampleModal<?= $post['no'] ?>"><span class="fa fa-edit"></span></button>
            
		    </div>

    </div>
		  </div><br><br></center>


<!-- Modal -->
<div class="modal fade" id="staticBackdrop" data-bs-backdrop="static" data-bs-keyboard="false" tabindex="-1" aria-labelledby="staticBackdropLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h1 class="modal-title" id="staticBackdropLabel">Tambah Postingan</h1>
        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
      </div>
      <div class="modal-body">
      <form action="proses_tambah.php" method="post" enctype="multipart/form-data">
        <label for="">Gambar</label><br>
        <input type="file" name="gambar" id="" class="form-control" required><br><br>

        <label for="">Caption</label><br>
        <textarea name="caption" id="" class="form-control" autocomplete="off" required></textarea><br><br>

        <label for="">Lokasi</label><br>
        <input type="text" name="lokasi" id="" class="form-control" autocomplete="off" required><br><br>

        <input type="submit" value="SIMPAN" name="simpan" class="btn btn-success">
    </form>
      </div>
      <div class="modal-footer">
      </div>
    </div>
  </div>
</div><br>

            <div class="modal fade" id="exampleModal<?= $post['no'] ?>" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel"
    aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">

            <div class="modal-header">
            <h1 class="modal-title fs-5" id="exampleModalLabel">Edit Postingan</h1>
            <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>   
            </div><div class="container">
            <h3 class="modal-title" id="staticBackdropLabel"></h3><br>
            <form action="proses_edit.php" method="post" enctype="multipart/form-data">
        <input type="hidden" name="no" value="<?= $post['no'] ?>">
        <input type="hidden" name="gambar_lama" value="<?= $post['gambar'] ?>">

        <label for="">Gambar</label><br>
        <input type="file" name="gambar" id="" class="form-control" value="<?= $post['gambar'] ?>"> <br><br>
        <img src="gambar/<?= $post['gambar'] ?>" alt="" width="100"><br><br>

        <label for="">Caption</label><br>
        <!-- <input type="text" name="caption" id="" class="form-control" autocomplete="off" value="<?= $post['caption'] ?>" required><br><br> -->
        <textarea name="caption" class="form-control" autocomplete="off" id="" required><?= $post['caption'] ?></textarea>

        <label for="">Lokasi</label><br>
        <input type="text" name="lokasi" id="" class="form-control" autocomplete="off" value="<?= $post['lokasi'] ?>" required><br><br>

        <input type="submit" value="UPDATE" name="update" class="btn btn-warning"><br><br>
    </form>
        </div></div>
        </div>
        </div>      
    
 <?php } ?>

  <script>
    function confirmDelete(postId){
      Swal.fire({
        title: 'Anda yakin akan menghapus data ini?',
        text: "jika anda menghapusnya, anda tidak akan dapat mengembalikkan data ini lagi",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        ConfirmButtonText: 'Ya',
        cancelButtonColor: '#3085d6',
        cancelButtonText: 'Batal'
      }).then(result => {
        if(result.isConfirmed){
          window.location.href = 'hapus.php?no=' + postId;
        }
      });
    }
  </script>

</body>
</html>


  <!-- <footer class="text-center text-lg-start sticky-top" height="20" style="background-color: black">

     Copyright 
    <div class="text-center text-black p-3" style="background-color: black">
    <div class="d-flex justify-content-around">
        <i class="fa fa-home" style="font-size:20px;color:white"></i>
        <i class="fa fa-search" style="font-size:20px;color:white"></i> 
        <i class="fa fa-caret-square-o-right" style="font-size:20px;color:white"></i> 
        <i class="fa fa-archive" style="font-size:20px;color:white"></i> 
        <i class="fa fa-user-circle-o" style="font-size:20px;color:white"></i> 
    </div></div>
  </footer> -->


